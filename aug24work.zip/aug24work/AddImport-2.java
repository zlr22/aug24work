import java.util.*;


public class AddImport {

    public static void main(String args[]) {
        javax.swing.JLabel label = new javax.swing.JLabel("hello");

    }

}
