import java.util.Scanner;
public class NameMaker {
    
    public static void main(String args[])
    {
        Scanner firstName = new Scanner(System.in);
        System.out.println("Enter First Name: ");
        Scanner middleName = new Scanner(System.in);
        System.out.println("Enter Middle Name: ");
        Scanner lastName = new Scanner(System.in);
        System.out.println("Enter Last Name: ");
        
        String fullName = firstname + " " + middleName + " " + lastName;
        
        System.out.println(fullName);
    }
    
}
