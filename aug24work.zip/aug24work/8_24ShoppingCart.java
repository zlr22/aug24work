
public class ShoppingCart {
    public static void main (String[] args){
        String custName = "Steve Smith";
        int spaceIdx = custName.indexOf('');
        String firstName = custName.substring(0,spaceIDx);
        System.out.pritnln(firstname);
        
        
        // Get the index of the space character (" ") in custName. 


        // Use the substring method parse out the first name and print it.


    }

    
}

