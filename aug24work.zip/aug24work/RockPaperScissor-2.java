import java.util.Random;
public class RockPaperScissor {

    public static void main(String[] args) {
        Random rand = new Random();
        int chance = rand.nextInt(3);
        System.out.println(chance);
        
        

    }
}
//rock = 1 paper = 3 scissors = 5