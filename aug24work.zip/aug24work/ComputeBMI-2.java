
import java.util.Scanner;
import java.lang.Math;


public class ComputeBMI {
    public static void main(String[] args)
    
	{
	    double weight = 170.2;
	    double height = 70.6;
        int BMI = Math.round((weight/Math.pow(height,2))*703);
        System.out.println(BMI);
        
        }
}
